import React from 'react';
import MaskItem from './components/MaskItem'

function App() {
  return (
    <MaskItem/>
  );
}

export default App;
